const authPage = document.getElementById('auth-page');
const mainPage = document.getElementById('main-page');
const profilePage = document.getElementById('profile-page');
const singlePlayerPage = document.getElementById('single-player-page');
const resultsPage = document.getElementById('results-page');

const loginBtn = document.getElementById('login-btn');
const registerBtn = document.getElementById('register-btn');
const profileBtn = document.getElementById('profile-btn');
const backToMainBtn = document.getElementById('back-to-main');
const saveProfileBtn = document.getElementById('save-profile');
const singlePlayerBtn = document.getElementById('single-player');
const playAgainBtn = document.getElementById('play-again');
const backToMainFromResultsBtn = document.getElementById('back-to-main-from-results');

const displayUsername = document.getElementById('display-username');
const editUsername = document.getElementById('edit-username');
const editUserId = document.getElementById('edit-user-id');
const userAvatar = document.getElementById('user-avatar');

const questionText = document.getElementById('question-text');
const optionsList = document.getElementById('options-list');
const timerElement = document.getElementById('timer');
const currentScoreElement = document.getElementById('current-score');
const finalScoreElement = document.getElementById('final-score');

let currentUser = null;
let score = 0;
let timer = 10;
let timerInterval;

const questions = [
    { question: "ما هي عاصمة فرنسا؟", options: ["باريس", "لندن", "برلين", "مدريد"], correctAnswer: "باريس" },
    { question: "ما هو الكوكب الأحمر؟", options: ["الأرض", "المريخ", "المشتري", "زحل"], correctAnswer: "المريخ" },
    // إضافة المزيد من الأسئلة هنا
];

// تسجيل الدخول
loginBtn.addEventListener('click', () => {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    // هنا يمكنك إضافة التحقق من قاعدة البيانات
    currentUser = { username, password };
    authPage.classList.add('hidden');
    mainPage.classList.remove('hidden');
    displayUsername.textContent = username;
});

// الانتقال إلى الملف الشخصي
profileBtn.addEventListener('click', () => {
    mainPage.classList.add('hidden');
    profilePage.classList.remove('hidden');
    editUsername.value = currentUser.username;
});

// حفظ التغييرات في الملف الشخصي
saveProfileBtn.addEventListener('click', () => {
    currentUser.username = editUsername.value;
    displayUsername.textContent = currentUser.username;
});

// العودة إلى الصفحة الرئيسية
backToMainBtn.addEventListener('click', () => {
    profilePage.classList.add('hidden');
    mainPage.classList.remove('hidden');
});

// بدء اللعب الانفرادي
singlePlayerBtn.addEventListener('click', () => {
    mainPage.classList.add('hidden');
    singlePlayerPage.classList.remove('hidden');
    startGame();
});

// بدء اللعبة
function startGame() {
    score = 0;
    currentScoreElement.textContent = score;
    loadQuestion();
}

// تحميل السؤال
function loadQuestion() {
    const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
    questionText.textContent = randomQuestion.question;
    optionsList.innerHTML = '';
    randomQuestion.options.forEach(option => {
        const li = document.createElement('li');
        li.textContent = option;
        li.addEventListener('click', () => checkAnswer(option, randomQuestion.correctAnswer));
        optionsList.appendChild(li);
    });
    startTimer();
}

// التحقق من الإجابة
function checkAnswer(selectedOption, correctAnswer) {
    clearInterval(timerInterval);
    if (selectedOption === correctAnswer) {
        score += 5;
        currentScoreElement.textContent = score;
    }
    if (questions.length > 0) {
        loadQuestion();
    } else {
        endGame();
    }
}

// بدء المؤقت
function startTimer() {
    timer = 10;
    timerElement.textContent = timer;
    timerInterval = setInterval(() => {
        timer--;
        timerElement.textContent = timer;
        if (timer <= 0) {
            clearInterval(timerInterval);
            checkAnswer(null, null);
        }
    }, 1000);
}

// إنهاء اللعبة
function endGame() {
    singlePlayerPage.classList.add('hidden');
    resultsPage.classList.remove('hidden');
    finalScoreElement.textContent = score;
}

// العودة إلى الصفحة الرئيسية من النتائج
backToMainFromResultsBtn.addEventListener('click', () => {
    resultsPage.classList.add('hidden');
    mainPage.classList.remove('hidden');
});

// اللعب مرة أخرى
playAgainBtn.addEventListener('click', () => {
    resultsPage.classList.add('hidden');
    singlePlayerPage.classList.remove('hidden');
    startGame();
});